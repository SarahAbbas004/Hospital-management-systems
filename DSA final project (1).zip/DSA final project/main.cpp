#include <iostream>
#include <string>
#include <vector>
using namespace std;


// Node for LinkedList
template <typename T>
class Node {
public:
    T data;
    Node* next;

    Node(const T& item) : data(item), next(nullptr) {}
};

// LinkedList class
template <typename T>
class LinkedList {
private:
    Node<T>* head;

public:
    LinkedList() : head(nullptr) {}

    ~LinkedList() {
        while (head) {
            Node<T>* temp = head;
            head = head->next;
            delete temp;
        }
    }

    void insert(const T& item) {
        Node<T>* newNode = new Node<T>(item);
        newNode->next = head;
        head = newNode;
    }

    void display() const {
        Node<T>* current = head;
        while (current) {
            cout << current->data << " ";
            current = current->next;
        }
        cout << endl;
    }
};

// Stack class
template <typename T>
class Stack {
private:
    LinkedList<T> list;

public:
    void push(const T& item) {
        list.insert(item);
    }

    T pop() {
        if (isEmpty()) {
            cerr << "Stack is empty" << endl;
            exit(EXIT_FAILURE);
        }

        Node<T>* topNode = list.head;
        T data = topNode->data;
        list.head = topNode->next;
        delete topNode;
        return data;
    }

    T peek() const {
        if (isEmpty()) {
            cerr << "Stack is empty" << endl;
            exit(EXIT_FAILURE);
        }
        return list.head->data;
    }

    bool isEmpty() const {
        return list.head == nullptr;
    }

    void display() const {
        list.display();
    }
};

class Diagnosis {
public:
    string diagnosisID;
    string diagnosisDescription;
    string diagnosisType;
};

class Patient {
public:
    string patientID;
    string patientName;
    string patientAge;
    string patientGender;
    string patientAddress;
    string patientPhone;
    vector<Diagnosis> patientDiagnoses;

    Patient* next; // Pointer to the next patient in the linked list
};

class Doctor {
public:
    string doctorID;
    string doctorName;
    string doctorAge;
    string doctorGender;
    string doctorAddress;
    string doctorPhone;
    string doctorSpecialization;

    Doctor* next; // Pointer to the next doctor in the linked list
};

class Nurse {
public:
    string nurseID;
    string nurseName;
    string nurseAge;
    string nurseGender;
    string nurseAddress;
    string nursePhone;
    string nurseSpecialization;

    Nurse* next; // Pointer to the next nurse in the linked list
};

class Staff {
public:
    string staffID;
    string staffName;
    string staffAge;
    string staffGender;
    string staffAddress;
    string staffPhone;
    string staffDesignation;

    Staff* next; // Pointer to the next staff in the linked list
};
class Ward {
    public:
    string wardID;
    string wardType;
    string wardCapacity;
    string wardOccupancy;
    Ward* next;
};

class Room {
    public:
    string roomID;
    string roomType;
    string roomCapacity;
    string roomOccupancy;
    Room* next;
};

class Department {
    public:
    string departmentID;
    string departmentName;
    string departmentType;
    Department* next;
};


class Medicine {
    public:
    string medicineID;
    string medicineName;
    string medicineType;
    string medicineDosage;
    string medicinePrescription;
    Medicine* next;
};

class Billing {
    public:
    string billingID;
    string patientID;
    string treatmentDetails;
    string billAmount;
    string billStatus;
    Billing* next;
};

class User {
    public:
    string userID;
    string userName;
    string userPassword;
    string userType;
    User* next;
};


class QueueNode {
public:
    Patient* patient;
    QueueNode* next; // Pointer to the next node in the queue
};

class HistoryQueue {
private:
    QueueNode* front;
    QueueNode* rear;

public:
    HistoryQueue() : front(nullptr), rear(nullptr) {}

    void enqueue(Patient* patient) {
        QueueNode* newNode = new QueueNode();
        newNode->patient = patient;
        newNode->next = nullptr;

        if (rear == nullptr) {
            // If the queue is empty, set both front and rear to the new node
            front = rear = newNode;
        } else {
            // Otherwise, add the new node to the rear and update the rear pointer
            rear->next = newNode;
            rear = newNode;
        }
    }

    void dequeue() {
        if (front == nullptr) {
            // Queue is empty
            return;
        }

        QueueNode* temp = front;
        front = front->next;

        if (front == nullptr) {
            // If the queue becomes empty, update the rear pointer
            rear = nullptr;
        }

        delete temp;
    }

    void displayHistory() {
        QueueNode* current = front;

        while (current != nullptr) {
            cout << "Patient ID: " << current->patient->patientID << ", Name: " << current->patient->patientName << endl;
            current = current->next;
        }
    }

    ~HistoryQueue() {
        while (front != nullptr) {
            dequeue();
        }
    }
};

// Functions for the system

void addPatient(Patient*& patientList) {
    Patient* newPatient = new Patient();
    cout << "Enter patient details: " << endl;
    cout << "ID: ";
    cin >> newPatient->patientID;
    cout << "Name: ";
    cin.ignore();
    getline(cin, newPatient->patientName);
    cout << "Age: ";
    cin >> newPatient->patientAge;
    cout << "Gender: ";
    cin >> newPatient->patientGender;
    cout << "Address: ";
    cin.ignore();
    getline(cin, newPatient->patientAddress);
    cout << "Phone: ";
    cin >> newPatient->patientPhone;

    // Add the new patient to the front of the linked list
    newPatient->next = patientList;
    patientList = newPatient;
}

void addDoctor(Doctor*& doctorList) {
    Doctor* newDoctor = new Doctor();
    cout << "Enter doctor details: " << endl;
    cout << "ID: ";
    cin >> newDoctor->doctorID;
    cout << "Name: ";
    cin.ignore();
    getline(cin, newDoctor->doctorName);
    cout << "Age: ";
    cin >> newDoctor->doctorAge;
    cout << "Gender: ";
    cin.ignore();
    getline(cin, newDoctor->doctorGender);
    cout << "Address: ";
    cin.ignore();
    getline(cin, newDoctor->doctorAddress);
    cout << "Phone: ";
    cin >> newDoctor->doctorPhone;
    cout << "Specialization: ";
    cin.ignore();
    getline(cin, newDoctor->doctorSpecialization);

    // Add the new doctor to the front of the linked list
    newDoctor->next = doctorList;
    doctorList = newDoctor;
}

void addNurse(Nurse*& nurseList) {
    Nurse* newNurse = new Nurse();
    cout << "Enter nurse details: " << endl;
    cout << "ID: ";
    cin >> newNurse->nurseID;
    cout << "Name: ";
    cin.ignore();
    getline(cin, newNurse->nurseName);
    cout << "Age: ";
    cin >> newNurse->nurseAge;
    cout << "Gender: ";
    cin >> newNurse->nurseGender;
    cout << "Address: ";
    cin.ignore();
    getline(cin, newNurse->nurseAddress);
    cout << "Phone: ";
    cin >> newNurse->nursePhone;
    cout << "Specialization: ";
    cin.ignore();
    getline(cin, newNurse->nurseSpecialization);

    // Add the new nurse to the front of the linked list
    newNurse->next = nurseList;
    nurseList = newNurse;
}

void addStaff(Staff*& staffList) {
    Staff* newStaff = new Staff();
    cout << "Enter staff details: " << endl;
    cout << "ID: ";
    cin >> newStaff->staffID;
    cout << "Age: ";
    cin >> newStaff->staffAge;
    cout << "Gender: ";
    cin >> newStaff->staffGender;
    cout << "Address: ";
    cin.ignore();
    getline(cin, newStaff->staffAddress);
    cout << "Phone: ";
    cin >> newStaff->staffPhone;
    cout << "Designation: ";
    cin.ignore();
    getline(cin, newStaff->staffDesignation);

    // Add the new staff to the front of the linked list
    newStaff->next = staffList;
    staffList = newStaff;
}

void addWard(Ward*& wardList) {
    Ward* newWard = new Ward();
    cout << "Enter ward details: " << endl;
    cout << "ID: ";
    cin >> newWard->wardID;
    cout << "Type: ";
    cin.ignore();
    getline(cin, newWard->wardType);
    cout << "Capacity: ";
    cin >> newWard->wardCapacity;
    cout << "Occupancy: ";
    cin >> newWard->wardOccupancy;

    // Add the new ward to the front of the linked list
    newWard->next = wardList;
    wardList = newWard;
}

void addRoom(Room*& roomList) {
    Room* newRoom = new Room();
    cout << "Enter room details: " << endl;
    cout << "ID: ";
    cin >> newRoom->roomID;
    cout << "Type: ";
    cin.ignore();
    getline(cin, newRoom->roomType);
    cout << "Capacity: ";
    cin >> newRoom->roomCapacity;
    cout << "Occupancy: ";
    cin >> newRoom->roomOccupancy;

    // Add the new room to the front of the linked list
    newRoom->next = roomList;
    roomList = newRoom;
}

void addDepartment(Department*& departmentList) {
    Department* newDepartment = new Department();
    cout << "Enter department details: " << endl;
    cout << "ID: ";
    cin >> newDepartment->departmentID;
    cout << "Name: ";
    cin.ignore();
    getline(cin, newDepartment->departmentName);
    cout << "Type: ";
    cin >> newDepartment->departmentType;

    // Add the new department to the front of the linked list
    newDepartment->next = departmentList;
    departmentList = newDepartment;
}

int main() {
    Patient* patientList = nullptr;
    Doctor* doctorList = nullptr;
    Nurse* nurseList = nullptr;
    Staff* staffList = nullptr;
    Ward* wardList = nullptr;
    Room* roomList = nullptr;
    Department* departmentList = nullptr;

    HistoryQueue historyQueue;

    int choice;

    do {
        cout << "Choose an option:" << endl;
        cout << "1. Add Patient Data" << endl;
        cout << "2. Add Doctor Data" << endl;
        cout << "3. Add Nurse Data" << endl;
        cout << "4. Add Staff Data" << endl;
        cout << "5. Add Ward Data" << endl;
        cout << "6. Add Room Data" << endl;
        cout << "7. Add Department Data" << endl;
        cout << "8. Display Patient Medical History" << endl;
        cout << "9. Exit" << endl;

        cin >> choice;

        switch (choice) {
            case 1:
                addPatient(patientList);
                break;
            case 2:
                addDoctor(doctorList);
                break;
            case 3:
                addNurse(nurseList);
                break;
            case 4:
                addStaff(staffList);
                break;
            case 5:
                addWard(wardList);
                break;
            case 6:
                addRoom(roomList);
                break;
            case 7:
                addDepartment(departmentList);
                break;
            case 8:
                historyQueue.displayHistory();
                break;
            case 9:
                cout << "Exiting program." << endl;
                break;
            default:
                cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 9);

    return 0;
}
