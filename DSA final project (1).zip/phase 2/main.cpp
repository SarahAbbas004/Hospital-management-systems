#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Patient {
    public:
    string patientID;
    string patientName;
    string patientAge;
    string patientGender;
    string patientAddress;
    string patientPhone;
    string patientEmail;
    string patientPassword;
};

class Doctor {
    public:
    string doctorID;
    string doctorName;
    string doctorAge;
    string doctorGender;
    string doctorAddress;
    string doctorPhone;
    string doctorEmail;
     string doctorPassword;
    string doctorSpecialization;
};

class Nurse {
    public:
    string nurseID;
    string nurseName;
    string nurseAge;
    string nurseGender;
    string nurseAddress;
    string nursePhone;
    string nurseEmail;
    string nursePassword;
    string nurseSpecialization;
};

class Staff {
    public:
    string staffID;
    string staffName;
    string staffAge;
    string staffGender;
    string staffAddress;
    string staffPhone;
    string staffEmail;
    string staffPassword;
    string staffDesignation;
};

class Ward {
    public:
    string wardID;
    string wardType;
    string wardCapacity;
    string wardOccupancy;
};

class Room {
    public:
    string roomID;
    string roomType;
    string roomCapacity;
    string roomOccupancy;
};

class Department {
    public:
    string departmentID;
    string departmentName;
    string departmentType;
};

class Diagnosis {
    public:
    string diagnosisID;
    string diagnosisDescription;
    string diagnosisType;
};

class Medicine {
    public:
    string medicineID;
    string medicineName;
    string medicineType;
    string medicineDosage;
    string medicinePrescription;
};

class Billing {
    public:
    string billingID;
    string patientID;
    string treatmentDetails;
    string billAmount;
    string billStatus;
};

class User {
    public:
    string userID;
    string userName;
    string userPassword;
    string userType;
};

// Functions for the system

void addPatient(vector<Patient>& patientList) {
    Patient newPatient;
    cout << "Enter patient details: ";
    cin >> newPatient.patientID;
    cin >> newPatient.patientName;
    cin >> newPatient.patientAge;
    cin >> newPatient.patientGender;
    cin >> newPatient.patientAddress;
    cin >> newPatient.patientPhone;
    cin >> newPatient.patientEmail;
    cin >> newPatient.patientPassword;

    patientList.push_back(newPatient);
}

void addDoctor(vector<Doctor>& doctorList) {
    Doctor newDoctor;
    cout << "Enter doctor details: ";
    cin >> newDoctor.doctorID;
    cin >> newDoctor.doctorName;
    cin >> newDoctor.doctorAge;
    cin >> newDoctor.doctorGender;
    cin >> newDoctor.doctorAddress;
    cin >> newDoctor.doctorPhone;
    cin >> newDoctor.doctorEmail;
    cin >> newDoctor.doctorPassword;
    cin >> newDoctor.doctorSpecialization;

    doctorList.push_back(newDoctor);
}

// Similarly, add functions for adding Nurses, Staff, Wards, Rooms, Departments, Diagnoses, Medicines, Billings, and Users.

int main() {
    vector<Patient> patientList;
    vector<Doctor> doctorList;
    vector<Nurse> nurseList;
    vector<Staff> staffList;
    vector<Ward> wardList;
    vector<Room> roomList;
    vector<Department>department;
}
